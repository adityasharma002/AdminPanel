import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import { Modal, Button, Form } from 'react-bootstrap';
import { FaTrash, FaEdit, FaPlus } from 'react-icons/fa';
import axios from 'axios';

const API_BASE = 'hhttps://logistic-project-backend.onrender.com/api/products'; // Change to match your backend

const Products = () => {
  const { categoryId } = useParams();
  const { state: categoryFromNav } = useLocation();

  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    productName: '',
    description: '',
    price: '',
  });
  const [editId, setEditId] = useState(null);

  // Fetch products on load or category change
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = categoryId
          ? await axios.get(`${API_BASE}/${categoryId}`)
          : await axios.get(API_BASE);
        setProducts(res.data || []);
      } catch (err) {
        console.error('Error fetching products:', err);
      }
    };
    fetchProducts();
  }, [categoryId]);

  const handleOpenModal = (product = null) => {
    if (product) {
      setFormData({
        productName: product.productName,
        description: product.description,
        price: product.price,
      });
      setEditId(product.id);
    } else {
      setFormData({ productName: '', description: '', price: '' });
      setEditId(null);
    }
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_BASE}/${id}`);
      setProducts((prev) => prev.filter((p) => p.id !== id));
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  const handleSubmit = async () => {
    const data = { ...formData, price: parseFloat(formData.price), categoryId: Number(categoryId) || null };
    try {
      if (editId) {
        await axios.put(`${API_BASE}/${editId}`, data);
        setProducts((prev) => prev.map((p) => (p.id === editId ? { ...p, ...data } : p)));
      } else {
        const res = await axios.post(API_BASE, data);
        setProducts((prev) => [...prev, res.data]);
      }
      setShowModal(false);
    } catch (err) {
      console.error('Submit error:', err);
    }
  };

  return (
    <div className="container py-4">
      <h3 className="fw-bold text-center mb-4">
        {categoryId ? `${categoryFromNav?.name || 'Category'} - Products` : 'All Products'}
      </h3>

      <div className="d-flex flex-wrap gap-4 justify-content-center">
        {products.map((prod) => (
          <div
            key={prod.id}
            className="shadow-sm p-3 bg-white rounded-4 text-center position-relative"
            style={{ width: '200px' }}
          >
            <div className="bg-light rounded-3 p-3 mb-2">
              <h5 className="m-0 fw-bold">{prod.productName.slice(0, 2).toUpperCase()}</h5>
            </div>
            <h6 className="fw-semibold">{prod.productName}</h6>
            <small className="text-muted d-block mb-2">{prod.description}</small>
            <p className="mb-2 fw-bold">₹{prod.price}</p>

            <div className="d-flex justify-content-center gap-2">
              <Button size="sm" variant="outline-primary" onClick={() => handleOpenModal(prod)}>
                <FaEdit />
              </Button>
              <Button size="sm" variant="outline-danger" onClick={() => handleDelete(prod.id)}>
                <FaTrash />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <Button
        variant="light"
        className="shadow-sm position-fixed"
        style={{
          width: '60px',
          height: '60px',
          borderRadius: '12px',
          fontSize: '1.5rem',
          bottom: '30px',
          right: '30px',
          zIndex: 999,
          border: '2px dashed #ccc',
          backgroundColor: '#f9f9f9',
        }}
        onClick={() => handleOpenModal()}
      >
        <FaPlus />
      </Button>

      {/* Modal */}
      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{editId ? 'Edit Product' : 'Add Product'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group className="mb-3">
            <Form.Label>Product Name</Form.Label>
            <Form.Control
              value={formData.productName}
              onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Description</Form.Label>
            <Form.Control
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Price (₹)</Form.Label>
            <Form.Control
              type="number"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>{editId ? 'Update' : 'Add'}</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Products;
