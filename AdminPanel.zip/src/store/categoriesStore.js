import { create } from 'zustand';
import axios from 'axios';

const API_BASE = 'https://logistic-project-backend.onrender.com/api/categories';

const useCategoriesStore = create((set, get) => ({
  categories: [],
  
  setCategories: (newList) => set({ categories: newList }),
  
  fetchCategories: async () => {
    try {
      const res = await axios.get(API_BASE);
      const apiCategories = res.data;
      
      // Retrieve saved images from localStorage
      const savedImages = JSON.parse(localStorage.getItem('categoryImages') || '{}');
      
      // Merge API data with saved images
      const mergedCategories = apiCategories.map(cat => ({
        ...cat,
        image: savedImages[cat.id] || '',
      }));
      
      set({ categories: mergedCategories });
      return mergedCategories;
    } catch (error) {
      console.error('Error fetching categories:', error);
      return [];
    }
  },
  
  addCategory: async (name, imageBase64) => {
    try {
      const res = await axios.post(API_BASE, { categoryName: name });
      const newCategoryId = res.data.id;
      const newCategory = { 
        ...res.data,
        image: imageBase64 
      };
      
      set((state) => ({
        categories: [...state.categories, newCategory],
      }));
      
      // Save image to localStorage
      if (imageBase64) {
        const savedImages = JSON.parse(localStorage.getItem('categoryImages') || '{}');
        savedImages[newCategoryId] = imageBase64;
        localStorage.setItem('categoryImages', JSON.stringify(savedImages));
      }
      
      return newCategoryId;
    } catch (error) {
      console.error('Error adding category:', error);
      throw error;
    }
  },
  
  updateCategory: async (id, name) => {
    try {
      await axios.put(`${API_BASE}/${id}`, { categoryName: name });
      
      set((state) => ({
        categories: state.categories.map((cat) =>
          cat.id === id ? { ...cat, name } : cat
        ),
      }));
      
      return true;
    } catch (error) {
      console.error('Error updating category:', error);
      throw error;
    }
  },
  
  deleteCategory: async (id) => {
    try {
      await axios.delete(`${API_BASE}/${id}`);
      
      set((state) => ({
        categories: state.categories.filter((cat) => cat.id !== id),
      }));
      
      return true;
    } catch (error) {
      console.error('Error deleting category:', error);
      throw error;
    }
  },
}));

export default useCategoriesStore;